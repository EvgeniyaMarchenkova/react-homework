export enum Genre {
  All = 'ALL',
  Documentary = 'DOCUMENTARY', 
  Comedy = 'COMEDY', 
  Horror = 'HORROR',
  Crime = 'CRIME',
}