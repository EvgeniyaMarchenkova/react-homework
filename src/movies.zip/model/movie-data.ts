import { Genre } from './genre';

export interface MovieData {
  value: string;
  genre: Genre;
  disabled: boolean;
}